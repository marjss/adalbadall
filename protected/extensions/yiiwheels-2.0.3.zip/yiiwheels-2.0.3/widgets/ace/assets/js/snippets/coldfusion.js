define('ace/snippets/coldfusion', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "coldfusion";

});

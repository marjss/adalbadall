define('ace/snippets/glsl', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "glsl";

});
